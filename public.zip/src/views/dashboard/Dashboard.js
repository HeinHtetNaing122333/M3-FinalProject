import React, { lazy, useEffect,useState } from 'react'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CCallout
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { useHistory } from 'react-router';
import ReactApexChart from 'react-apexcharts';
//npm install apexcharts react-apexcharts @coreui/react



const Dashboard = () => {

  const history = useHistory();
  
  
  useEffect(() => {
    let flag = localStorage.getItem(`LoginProcess`)
    if(flag != "true"){
      history.push(`/Login`);
    }
}, );


    const [chartData, setChartData] = useState({
      options: {
        chart: {
          id: 'basic-bar'
        },
        xaxis: {
          categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        }
      },
      series: [
        {
          name: 'New-Employee',
          data: [30, 40, 45, 50, 40, 60, 70, 91, 125, 100, 180, 200]
        }
      ]
    });
  return (
    <>
     
     <h1  style={{ textAlign: "center" }} >Welcome to Dashboard.</h1>
     <br></br><br></br><br></br><br></br>
     
    
    <ReactApexChart options={chartData.options} series={chartData.series} type="bar" height={350} />
    </>
  )
}


export default Dashboard
